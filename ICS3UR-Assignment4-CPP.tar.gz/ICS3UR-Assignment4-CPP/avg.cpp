// Copyright (c) 2020 St. Mother Teresa HS All Rights Reserved.
//
// Created by Gabriel A
// Created on Dec 2020
// This program calculates the average of 3 numbers between 0-100

#include <iostream>
#include <string>

int main() {
    int into;
    int intw;
    int inth;
    int average;
    std::string intoAsString;
    std::string intwAsString;
    std::string inthAsString;

    // input
    std::cout << "We are going to calculate the average of 3 numbers" <<
    std::endl;
    std::cout << "Enter a number between 0-100: ";
    std::cin >> intoAsString;
    std::cout << "Enter another number: ";
    std::cin >> intwAsString;
    std::cout << "Enter a third number: ";
    std::cin >> inthAsString;
    std::cout << "" << std::endl;

    try {
        into = std::stoi(intoAsString);
        intw = std::stoi(intwAsString);
        inth = std::stoi(inthAsString);
        average = (into + intw + inth) / 3;

        if (into >= 0 && into <= 100) {
            if (intw >= 0 && intw <= 100) {
                if (inth >= 0 && inth <= 100) {
                    std::cout << "The average is: " << average << std::endl;
                } else {
                    std::cout << "One or inputs are negative or above 100."
                    << std::endl;
                }
            } else {
                std::cout << "One or inputs are negative or above 100."
                << std::endl;
            }
        } else {
            std::cout << "One or inputs are negative or above 100."
            << std::endl;
        }
    } catch (std::invalid_argument) {
        std::cout << "One or more inputs are not valid. You entered letters."
        << std::endl;
    }
}
